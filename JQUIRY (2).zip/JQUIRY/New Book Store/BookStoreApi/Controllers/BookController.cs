﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace BookStoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private static List<Book> books = new List<Book>()
        {
            new Book {
        Id=1,
        Title= "Hazrat Umar Farooq E Azam",
        Author= "Habib Ashar Dehlvi",
        Description = "A detailed biography of Hazrat Umar Farooq.",
        Image = "Book Covers/Book cover 2.webp"
        },
            new Book {
        Id=2,
        Title = "SALADIN",
        Author = "Unknown",
        Description = "A comprehensive account of Saladin's life.",
        Image = "Book Covers/Book cover 1.jpeg"
    },
            new Book {
        Id=3,
        Title = "Light in Gaza",
        Author = "Alperen Bayrak",
        Description = "A historical perspective on Gaza.",
        Image = "Book Covers/Book cover 4.jpeg"
    },
            new Book {
        Id =4,
        Title = "Muhammad Bin Qasim",
        Author = "Alperen Bayrak",
        Description = "A historical background of one of the gretest conqour..",
        Image = "Book Covers/Book cover 3.jpeg"
    },
             new Book {
        Id=1,
        Title= "Hazrat Umar Farooq E Azam",
        Author= "Habib Ashar Dehlvi",
        Description = "A detailed biography of Hazrat Umar Farooq.",
        Image = "Book Covers/Book cover 2.webp"
        },
            new Book {
        Id=2,
        Title = "SALADIN",
        Author = "Unknown",
        Description = "A comprehensive account of Saladin's life.",
        Image = "Book Covers/Book cover 1.jpeg"
    },
            new Book {
        Id=3,
        Title = "Light in Gaza",
        Author = "Alperen Bayrak",
        Description = "A historical perspective on Gaza.",
        Image = "Book Covers/Book cover 4.jpeg"
    },
            new Book {
        Id =4,
        Title = "Muhammad Bin Qasim",
        Author = "Alperen Bayrak",
        Description = "A historical background of one of the gretest conqour..",
        Image = "Book Covers/Book cover 3.jpeg"
    },
             new Book {
        Id=1,
        Title= "Hazrat Umar Farooq E Azam",
        Author= "Habib Ashar Dehlvi",
        Description = "A detailed biography of Hazrat Umar Farooq.",
        Image = "Book Covers/Book cover 2.webp"
        },
            new Book {
        Id=2,
        Title = "SALADIN",
        Author = "Unknown",
        Description = "A comprehensive account of Saladin's life.",
        Image = "Book Covers/Book cover 1.jpeg"
    },
            new Book {
        Id=3,
        Title = "Light in Gaza",
        Author = "Alperen Bayrak",
        Description = "A historical perspective on Gaza.",
        Image = "Book Covers/Book cover 4.jpeg"
    },
            new Book {
        Id =4,
        Title = "Muhammad Bin Qasim",
        Author = "Alperen Bayrak",
        Description = "A historical background of one of the gretest conqour..",
        Image = "Book Covers/Book cover 3.jpeg"
    }
        };

        // GET: api/Book
        [HttpGet]
        public ActionResult<IEnumerable<Book>> Get()
        {
            return Ok(books);
        }

        // GET api/Book/5
        [HttpGet("{id}")]
        public ActionResult<Book> Get(int id)
        {
            var book = books.FirstOrDefault(b => b.Id == id);
            if (book == null)
            {
                return NotFound(new { Message = "Book Not Found" });
            }
            return Ok(book);
        }

        // POST api/Book
        [HttpPost]
        public ActionResult<Book> Post([FromBody] Book book)
        {
            book.Id = books.Max(b => b.Id) + 1;
            books.Add(book);
            return CreatedAtAction(nameof(Get), new { id = book.Id }, book);
        }

        // PUT api/Book/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Book book)
        {
            var existingBook = books.FirstOrDefault(b => b.Id == id);
            if (existingBook == null)
            {
                return NotFound(new { Message = "Book Not Found" });
            }
            existingBook.Title = book.Title;
            existingBook.Description = book.Description;
            existingBook.Author = book.Author;
            existingBook.Image = book.Image;
            return NoContent();
        }

        // DELETE api/Book/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var book = books.FirstOrDefault(a => a.Id == id);
            if (book == null)
            {
                return NotFound(new { Message = "Book Not Found" });
            }
            books.Remove(book);
            return NoContent();
        }

        // GET api/Book/author/PM
        [HttpGet("author/{author}")]
        public ActionResult<IEnumerable<Book>> GetByAuthor(string author)
        {
            var booksByAuthor = books.Where(b => b.Author == author).ToList();
            if (!booksByAuthor.Any())
            {
                return NotFound(new { Message = "Books by Author Not Found" });
            }
            return Ok(booksByAuthor);
        }
    }
}
